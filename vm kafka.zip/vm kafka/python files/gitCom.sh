git add .
git commit -m "multiple commito"
git push
#result = attente(timeout=5)
git status
